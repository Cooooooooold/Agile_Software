# MarketDashboardJetpackComposeTutorial
This is a Simple yet beautify Marketing Dashboard implemented in Jetpack compose. make sure you watch the tutorial code along video on youtube

![title](images/view.png)
